/**
 * Classes which intercept operations related to Hibernate persistent objects.
 * This provides an alternate to AspectJ for interception.
 */
package ore.hibernate;