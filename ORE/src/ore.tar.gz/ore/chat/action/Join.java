package ore.chat.action;

import static ore.util.HTTPServletUtil.getRequiredParameter;

import java.util.Set;

import ore.api.ORE;
import ore.chat.entity.ChatSession;
import ore.chat.entity.User;
import ore.chat.event.MessageListener;
import ore.chat.event.UsersListener;

public class Join extends Action {

	@Override
	protected void run() {
		try {
			String roomName = getRequiredParameter(request, ROOM_NAME);
			String userName = getRequiredParameter(request, USER_NAME);	
			User user = (User) session.get(User.class, userName);
			if(user == null) {
				user = new User(userName);
			}
			ChatSession room = (ChatSession) session.get(ChatSession.class, roomName);
			Set<ChatSession> rooms = user.getRooms();
			if(rooms != null) {
				rooms.clear();
			}
			room.userJoined(user);
			ORE.addCollectionChangeListener(room, "messages", new MessageListener());
			ORE.addCollectionChangeListener(room, "currentUsers", new UsersListener());
			pw.print(room.toJSON());
			session.saveOrUpdate(room);
			session.saveOrUpdate(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
