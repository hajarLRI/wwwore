/**
 * Exception classes specific to ORE (made only one so far).
 */
package ore.exception;