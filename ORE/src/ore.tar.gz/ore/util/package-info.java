/**
 * Convenience classes used by ORE internals and can also be used by ORE users.
 */
package ore.util;