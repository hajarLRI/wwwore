/**
 * Comet session establishment and long-polling maintenance.
 */
package ore.servlet;