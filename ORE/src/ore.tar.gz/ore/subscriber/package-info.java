/**
 * Classes which implement buffering and routing of events to specific clients
 * using their Comet connections.
 */
package ore.subscriber;